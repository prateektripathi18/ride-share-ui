package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;
import com.internshipprojectG1.ride_sharing.requests.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UsersRepo usersRepo;

    public Users addUser(Users user) {
        return usersRepo.save(user);
    }

    public Users loginUser(LoginRequest loginRequest) {
        Optional<Users> user = usersRepo.findById(loginRequest.getEmail());

        if (user.isEmpty()) {
            return null;
        }

        Users foundUser = user.get();

        if (!foundUser.getPassword().equals(loginRequest.getPassword())) {
            return null;
        }

        return foundUser;
    }

    // ----------------------
    // NEW: Update Password
    // ----------------------
    public void updatePassword(String email, String newPassword) {
        Optional<Users> userOpt = usersRepo.findById(email);

        if (userOpt.isPresent()) {
            Users user = userOpt.get();
            user.setPassword(newPassword);
            usersRepo.save(user);
        }
    }
}
