package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.entity.Ride;
import com.internshipprojectG1.ride_sharing.repository.RideRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RideService {

    private final RideRepository rideRepository;

    public RideService(RideRepository rideRepository) {
        this.rideRepository = rideRepository;
    }

    public Ride addRide(Ride ride) {
        return rideRepository.save(ride);
    }

    public List<Ride> searchRides(String fromCity, String toCity) {
        return rideRepository.findByFromCityAndToCity(fromCity, toCity);
    }
}
