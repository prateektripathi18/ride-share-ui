package com.internshipprojectG1.ride_sharing.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Ride {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fromCity;
    private String toCity;
    private LocalDateTime departureTime;
    private int seatsAvailable;

    private String driverEmail; // who is hosting the ride

    public Ride() {}

    public Ride(String fromCity, String toCity, LocalDateTime departureTime, int seatsAvailable, String driverEmail) {
        this.fromCity = fromCity;
        this.toCity = toCity;
        this.departureTime = departureTime;
        this.seatsAvailable = seatsAvailable;
        this.driverEmail = driverEmail;
    }

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFromCity() { return fromCity; }
    public void setFromCity(String fromCity) { this.fromCity = fromCity; }

    public String getToCity() { return toCity; }
    public void setToCity(String toCity) { this.toCity = toCity; }

    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime departureTime) { this.departureTime = departureTime; }

    public int getSeatsAvailable() { return seatsAvailable; }
    public void setSeatsAvailable(int seatsAvailable) { this.seatsAvailable = seatsAvailable; }

    public String getDriverEmail() { return driverEmail; }
    public void setDriverEmail(String driverEmail) { this.driverEmail = driverEmail; }
}
