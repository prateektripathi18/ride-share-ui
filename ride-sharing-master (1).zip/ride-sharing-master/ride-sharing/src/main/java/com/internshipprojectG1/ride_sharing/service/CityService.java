package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.entity.City;
import com.internshipprojectG1.ride_sharing.repository.CityRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityService {

    private final CityRepository cityRepository;

    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;
    }

    public List<City> getAllCities() {
        return cityRepository.findAll();
    }

    public City addCity(City city) {
        return cityRepository.save(city);
    }
}
