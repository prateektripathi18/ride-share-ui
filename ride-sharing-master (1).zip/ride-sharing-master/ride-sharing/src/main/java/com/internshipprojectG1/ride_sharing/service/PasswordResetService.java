package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.entity.PasswordResetToken;
import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.PasswordResetTokenRepository;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class PasswordResetService {

    @Autowired
    private UsersRepo usersRepo;

    @Autowired
    private PasswordResetTokenRepository tokenRepo;

    @Autowired
    private UserService userService;

    // --------------------------
    // 1) Create Reset Token
    // --------------------------
    public void createPasswordResetToken(String email, String appUrl) {

        Optional<Users> user = usersRepo.findById(email);

        // For security: do not reveal if email exists
        if (user.isEmpty()) return;

        // Delete old tokens
        tokenRepo.deleteByEmail(email);

        // Create new token
        String token = UUID.randomUUID().toString();

        PasswordResetToken resetToken = new PasswordResetToken(
                email,
                token,
                LocalDateTime.now().plusMinutes(15) // validity: 15 min
        );

        tokenRepo.save(resetToken);

        // Reset Link
        String resetLink = appUrl + "/reset-password?token=" + token;

        // ---- Send Email (Console Mode) ----
        System.out.println("Password Reset Link: " + resetLink);
    }

    // --------------------------
    // 2) Validate Token
    // --------------------------
    public boolean isTokenValid(String token) {

        PasswordResetToken resetToken = tokenRepo.findByToken(token);

        if (resetToken == null) return false;
        return resetToken.getExpiryDate().isAfter(LocalDateTime.now());
    }

    // --------------------------
    // 3) Reset Password
    // --------------------------
    public void resetPassword(String token, String newPassword) {
        PasswordResetToken resetToken = tokenRepo.findByToken(token);

        if (resetToken == null)
            throw new RuntimeException("Invalid token");

        if (resetToken.getExpiryDate().isBefore(LocalDateTime.now()))
            throw new RuntimeException("Token expired");

        userService.updatePassword(resetToken.getEmail(), newPassword);

        tokenRepo.delete(resetToken);
    }
}
