package com.internshipprojectG1.ride_sharing.repository;

import com.internshipprojectG1.ride_sharing.entity.PasswordResetToken;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Long> {

    PasswordResetToken findByToken(String token);

    void deleteByEmail(String email);
}
