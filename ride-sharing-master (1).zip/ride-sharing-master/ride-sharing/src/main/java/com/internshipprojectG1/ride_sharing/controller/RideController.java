package com.internshipprojectG1.ride_sharing.controller;

import com.internshipprojectG1.ride_sharing.entity.Ride;
import com.internshipprojectG1.ride_sharing.service.RideService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rides")
@CrossOrigin(origins = "http://localhost:5173") // your frontend port
public class RideController {

    private final RideService rideService;

    public RideController(RideService rideService) {
        this.rideService = rideService;
    }

    @PostMapping("/add")
    public Ride addRide(@RequestBody Ride ride) {
        return rideService.addRide(ride);
    }

    @GetMapping("/search")
    public List<Ride> searchRides(@RequestParam String from, @RequestParam String to) {
        return rideService.searchRides(from, to);
    }
}
