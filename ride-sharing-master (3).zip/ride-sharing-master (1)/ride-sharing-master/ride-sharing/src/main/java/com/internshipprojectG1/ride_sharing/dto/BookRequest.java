package com.internshipprojectG1.ride_sharing.dto;

public class BookRequest {
    private String passengerEmail;
    private int seats; // seats to book

    public String getPassengerEmail() {
        return passengerEmail;
    }

    public void setPassengerEmail(String passengerEmail) {
        this.passengerEmail = passengerEmail;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }
// getters & setters
}
