package com.internshipprojectG1.ride_sharing.repository;

import com.internshipprojectG1.ride_sharing.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {}
