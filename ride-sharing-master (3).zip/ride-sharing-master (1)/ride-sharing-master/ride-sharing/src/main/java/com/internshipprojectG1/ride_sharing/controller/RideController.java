package com.internshipprojectG1.ride_sharing.controller;

import com.internshipprojectG1.ride_sharing.dto.RideRequest;
import com.internshipprojectG1.ride_sharing.dto.BookRequest;
import com.internshipprojectG1.ride_sharing.entity.Ride;
import com.internshipprojectG1.ride_sharing.entity.Booking;
import com.internshipprojectG1.ride_sharing.service.RideService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/rides")
public class RideController {

    private final RideService rideService;

    public RideController(RideService rideService) {
        this.rideService = rideService;
    }

    // 1) Host a ride
    @PostMapping
    public ResponseEntity<Ride> createRide(@RequestBody RideRequest req) {
        Ride created = rideService.createRide(req);
        return ResponseEntity.ok(created);
    }

    // 2) Search rides
    @GetMapping
    public ResponseEntity<List<Ride>> searchRides(
            @RequestParam(required = false) String origin,
            @RequestParam(required = false) String destination,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime from,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime to
    ) {
        List<Ride> list = rideService.searchRides(origin, destination, from, to);
        return ResponseEntity.ok(list);
    }

    // 3) Book ride
    @PostMapping("/{rideId}/book")
    public ResponseEntity<Booking> bookRide(
            @PathVariable Long rideId,
            @RequestBody BookRequest req
    ) {
        Booking booking = rideService.bookRide(rideId, req);
        return ResponseEntity.ok(booking);
    }

    // 4) Hosted rides
    @GetMapping("/hosted")
    public ResponseEntity<List<Ride>> getHosted(@RequestParam String hostEmail) {
        List<Ride> list = rideService.getHostedRides(hostEmail);
        return ResponseEntity.ok(list);
    }
}
