package com.internshipprojectG1.ride_sharing.repository;

import com.internshipprojectG1.ride_sharing.entity.Users;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsersRepo extends JpaRepository<Users, String> {


    Optional<Users> findByEmail(String email);


    @Transactional
    @Modifying
    @Query("update Users u set u.password = ?2 where u.email= ?1")
    void updatePassword(String email, String password);
}
