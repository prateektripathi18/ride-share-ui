package com.internshipprojectG1.ride_sharing.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String carName;
    private String carNumber;
    private String carPhoto;   // URL or base64

    @ManyToOne
    @JoinColumn(name = "user_id")
    private Users user;
}
