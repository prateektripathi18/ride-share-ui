package com.internshipprojectG1.ride_sharing.repository;



import com.internshipprojectG1.ride_sharing.entity.Car;
import com.internshipprojectG1.ride_sharing.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
    List<Car> findByUser(Users user);
}