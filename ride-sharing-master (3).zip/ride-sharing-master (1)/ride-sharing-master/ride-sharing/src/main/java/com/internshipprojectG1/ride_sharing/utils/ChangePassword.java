package com.internshipprojectG1.ride_sharing.utils;

public record ChangePassword(String password, String repeatpassword) {
}
