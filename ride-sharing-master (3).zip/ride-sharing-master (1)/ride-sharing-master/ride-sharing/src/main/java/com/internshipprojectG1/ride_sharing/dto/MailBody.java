package com.internshipprojectG1.ride_sharing.dto;

import lombok.Builder;


@Builder
public record MailBody(String to, String subject,String text) {
}
