package com.internshipprojectG1.ride_sharing.controller;

import com.internshipprojectG1.ride_sharing.entity.Car;
import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.CarRepository;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@CrossOrigin("*")
public class CarController {

    @Autowired
    private UsersRepo usersRepo;

    @Autowired
    private CarRepository carRepository;

    // GET USER CARS
    @GetMapping("/{email}/cars")
    public ResponseEntity<?> getCarsByUser(@PathVariable String email) {
        Users user = usersRepo.findByEmail(email)
                .orElse(null);     // <-- FIXED: Optional handling

        if (user == null)
            return ResponseEntity.badRequest().body("User not found");

        List<Car> cars = carRepository.findByUser(user);
        return ResponseEntity.ok(cars);
    }

    // ADD CAR FOR USER
    @PostMapping("/{email}/cars")
    public ResponseEntity<?> addCar(
            @PathVariable String email,
            @RequestBody Car car
    ) {
        Users user = usersRepo.findByEmail(email)
                .orElse(null);     // <-- FIXED: Optional handling

        if (user == null)
            return ResponseEntity.badRequest().body("User not found");

        car.setUser(user);
        return ResponseEntity.ok(carRepository.save(car));
    }
}
