package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.entity.Users;
import org.apache.catalina.User;

public interface AdminService {
    Users getAdminByEmail(String email);
    Users updateProfile(String email, Users updatedUser);

    void updateProfile(String email, User updatedUser);
}
