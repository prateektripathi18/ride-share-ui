package com.internshipprojectG1.ride_sharing.controller;

import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/profile")
    public Users getProfile(Authentication auth) {
        return adminService.getAdminByEmail(auth.getName());
    }

    @PutMapping("/profile/update")
    public String updateProfile(@RequestBody Users userData, Authentication auth) {
        adminService.updateProfile(auth.getName(), userData);
        return "updated";
    }
}
