package com.internshipprojectG1.ride_sharing.repository;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties;

import java.util.Optional;

public class AdminRepository {
    Optional<KafkaProperties.Admin> findByEmail(String email) {
        return null;
    }

}

