package com.internshipprojectG1.ride_sharing.repository;

import com.internshipprojectG1.ride_sharing.entity.Ride;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDateTime;
import java.util.List;

public interface RideRepository extends JpaRepository<Ride, Long> {

    // Find open rides matching origin/destination and departure date range
    @Query("SELECT r FROM Ride r WHERE r.status = 'OPEN' "
            + "AND (:origin IS NULL OR LOWER(r.origin) LIKE LOWER(CONCAT('%',:origin,'%'))) "
            + "AND (:destination IS NULL OR LOWER(r.destination) LIKE LOWER(CONCAT('%',:destination,'%'))) "
            + "AND (:fromDate IS NULL OR r.departureAt >= :fromDate) "
            + "AND (:toDate IS NULL OR r.departureAt <= :toDate)"
    )
    List<Ride> search(String origin, String destination, LocalDateTime fromDate, LocalDateTime toDate);

    List<Ride> findByHost_Email(String hostEmail);
}
