package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.dto.RideRequest;
import com.internshipprojectG1.ride_sharing.dto.BookRequest;
import com.internshipprojectG1.ride_sharing.entity.Ride;
import com.internshipprojectG1.ride_sharing.entity.Booking;
import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.RideRepository;
import com.internshipprojectG1.ride_sharing.repository.BookingRepository;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo; // assume you have it
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RideService {

    private final RideRepository rideRepo;
    private final BookingRepository bookingRepo;
    private final UsersRepo usersRepo;

    public RideService(RideRepository rideRepo, BookingRepository bookingRepo, UsersRepo usersRepo) {
        this.rideRepo = rideRepo;
        this.bookingRepo = bookingRepo;
        this.usersRepo = usersRepo;
    }

    public Ride createRide(RideRequest req) {
        Users host = usersRepo.findById(req.getHostEmail())
                .orElseThrow(() -> new IllegalArgumentException("Host not found"));

        Ride r = new Ride();
        r.setHost(host);
        r.setOrigin(req.getOrigin());
        r.setDestination(req.getDestination());
        r.setDepartureAt(req.getDepartureAt());
        r.setTotalSeats(req.getTotalSeats());
        r.setSeatsAvailable(req.getTotalSeats());
        r.setPrice(req.getPrice());
        r.setDescription(req.getDescription());
        r.setStatus("OPEN");

        return rideRepo.save(r);
    }

    public List<Ride> searchRides(String origin, String destination, LocalDateTime from, LocalDateTime to) {
        return rideRepo.search(origin, destination, from, to);
    }

    @Transactional
    public Booking bookRide(Long rideId, BookRequest req) {
        Ride ride = rideRepo.findById(rideId)
                .orElseThrow(() -> new IllegalArgumentException("Ride not found"));

        if (!"OPEN".equals(ride.getStatus())) {
            throw new IllegalStateException("Ride not open for booking");
        }

        if (req.getSeats() <= 0) throw new IllegalArgumentException("Invalid seats");

        if (ride.getSeatsAvailable() < req.getSeats()) {
            throw new IllegalStateException("Not enough seats available");
        }

        Users passenger = usersRepo.findById(req.getPassengerEmail())
                .orElseThrow(() -> new IllegalArgumentException("Passenger not found"));

        // reduce seats
        ride.setSeatsAvailable(ride.getSeatsAvailable() - req.getSeats());
        rideRepo.save(ride);

        Booking book = new Booking();
        book.setRide(ride);
        book.setPassenger(passenger);
        book.setSeatsBooked(req.getSeats());
        book.setBookedAt(LocalDateTime.now());

        return bookingRepo.save(book);
    }

    public List<Ride> getHostedRides(String hostEmail) {
        return rideRepo.findByHost_Email(hostEmail);
    }
}
