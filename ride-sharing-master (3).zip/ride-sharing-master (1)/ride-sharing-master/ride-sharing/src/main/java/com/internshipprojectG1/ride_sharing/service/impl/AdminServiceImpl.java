package com.internshipprojectG1.ride_sharing.service.impl;

import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;
import com.internshipprojectG1.ride_sharing.service.AdminService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private UsersRepo usersRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public Users getAdminByEmail(String email) {
        return usersRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public Users updateProfile(String email, Users updatedUser) {

        Users user = usersRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setName(updatedUser.getName());
        user.setPhone(updatedUser.getPhone());

        if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
        }

        return usersRepo.save(user);
    }

    @Override
    public void updateProfile(String email, User updatedUser) {

    }
}
