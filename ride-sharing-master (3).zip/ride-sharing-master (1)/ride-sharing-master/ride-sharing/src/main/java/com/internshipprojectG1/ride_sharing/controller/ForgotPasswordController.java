package com.internshipprojectG1.ride_sharing.controller;

import com.internshipprojectG1.ride_sharing.dto.MailBody;
import com.internshipprojectG1.ride_sharing.entity.ForgotPassword;
import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.ForgotPasswordRepository;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;
import com.internshipprojectG1.ride_sharing.service.EmailService;
import com.internshipprojectG1.ride_sharing.utils.ChangePassword;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;

@RestController
@RequestMapping("/forgotPassword")
public class ForgotPasswordController {

    private final UsersRepo usersRepo;
    private final EmailService emailService;
    private final ForgotPasswordRepository forgotPasswordRepository;
    private final PasswordEncoder passwordEncoder;

    public ForgotPasswordController(UsersRepo usersRepo, EmailService emailService,
                                    ForgotPasswordRepository forgotPasswordRepository,
                                    PasswordEncoder passwordEncoder) {
        this.usersRepo = usersRepo;
        this.emailService = emailService;
        this.forgotPasswordRepository = forgotPasswordRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ========================= SEND OTP ==============================
    @PostMapping("/verifyMail/{email}")
    public ResponseEntity<String> verifyEmail(@PathVariable String email) {

        Users user = usersRepo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Please provide a valid email!"));

        int otp = otpGenerator();

        MailBody mailBody = MailBody.builder()
                .to(email)
                .text("This is the OTP for your forgot password request: " + otp)
                .subject("OTP for forgot password request")
                .build();

        Date expTime = new Date(System.currentTimeMillis() + 70 * 1000);

        // CHECK IF OTP ALREADY EXISTS
        Optional<ForgotPassword> existingOtp = forgotPasswordRepository.findByUser(user);

        if (existingOtp.isPresent()) {
            ForgotPassword existing = existingOtp.get();
            existing.setOtp(otp);
            existing.setExpirationTime(expTime);
            forgotPasswordRepository.save(existing);
        } else {
            ForgotPassword fp = ForgotPassword.builder()
                    .otp(otp)
                    .expirationTime(expTime)
                    .user(user)
                    .build();

            forgotPasswordRepository.save(fp);
        }

        emailService.sendSimpleMessage(mailBody);

        return ResponseEntity.ok("Email sent for verification!");
    }

    // ========================= VERIFY OTP ==============================
    @PostMapping("/verifyOtp/{otp}/{email}")
    public ResponseEntity<String> verifyOtp(@PathVariable Integer otp, @PathVariable String email) {

        Users user = usersRepo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Please provide a valid email!"));

        ForgotPassword fp = forgotPasswordRepository.findByOtpAndUsers(otp, user)
                .orElseThrow(() -> new RuntimeException("Invalid OTP for email: " + email));

        if (fp.getExpirationTime().before(Date.from(Instant.now()))) {
            forgotPasswordRepository.deleteById(fp.getFpid());
            return new ResponseEntity<>("OTP has expired!", HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok("OTP verified!");
    }

    // ========================= CHANGE PASSWORD ==============================
    @PostMapping("/changePassword/{email}")
    public ResponseEntity<String> changePasswordHandler(@RequestBody ChangePassword changePassword,
                                                        @PathVariable String email) {

        if (!Objects.equals(changePassword.password(), changePassword.repeatpassword())) {
            return new ResponseEntity<>("Password did not match!", HttpStatus.EXPECTATION_FAILED);
        }

        String encodePassword = passwordEncoder.encode(changePassword.password());
        usersRepo.updatePassword(email, encodePassword);

        // delete OTP after successful password change
        forgotPasswordRepository.deleteByEmail(email);

        return ResponseEntity.ok("Password has been changed");
    }

    private Integer otpGenerator() {
        Random random = new Random();
        return random.nextInt(900000) + 100000; // 6-digit OTP
    }
}
