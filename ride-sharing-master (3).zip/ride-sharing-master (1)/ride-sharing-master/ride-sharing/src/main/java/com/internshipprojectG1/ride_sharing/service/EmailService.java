package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.dto.MailBody;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender javaMailSender;

    public EmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public void sendSimpleMessage(MailBody mailBody){

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(mailBody.to());
        message.setFrom("aashusharma8897@gmail.com");
        message.setSubject(mailBody.subject());
        message.setText(mailBody.text());

        javaMailSender.send(message);
    }

    public void createPasswordResetToken(String email, String appUrl) {
    }

    public void resetPassword(String token, String newPassword) {
    }

    public boolean isTokenValid(String token) {
        return false;
    }
}
