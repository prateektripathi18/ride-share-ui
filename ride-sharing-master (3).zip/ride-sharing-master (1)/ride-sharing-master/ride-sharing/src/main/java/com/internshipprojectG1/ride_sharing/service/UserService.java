package com.internshipprojectG1.ride_sharing.service;

import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.repository.UsersRepo;
import com.internshipprojectG1.ride_sharing.requests.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UsersRepo usersRepo;

    @Autowired
    PasswordEncoder passwordEncoder;

    // ===================== REGISTER USER =====================
    public Users addUser(Users user) {

        // Encode password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        return usersRepo.save(user);
    }

    // ===================== LOGIN USER =====================
    public Users loginUser(LoginRequest loginRequest) {

        Optional<Users> user = usersRepo.findById(loginRequest.getEmail());

        if (user.isEmpty()) {
            return null;
        }

        Users foundUser = user.get();

        // Check encoded password
        if (!passwordEncoder.matches(loginRequest.getPassword(), foundUser.getPassword())) {
            return null;
        }

        return foundUser;
    }

    // ===================== UPDATE PASSWORD =====================
    public void updatePassword(String email, String newPassword) {

        Optional<Users> userOpt = usersRepo.findById(email);

        if (userOpt.isPresent()) {

            Users user = userOpt.get();

            // Encode new password
            user.setPassword(passwordEncoder.encode(newPassword));

            usersRepo.save(user);
        }
    }
}
