package com.internshipprojectG1.ride_sharing.controller;

import com.internshipprojectG1.ride_sharing.entity.Users;
import com.internshipprojectG1.ride_sharing.requests.LoginRequest;
import com.internshipprojectG1.ride_sharing.requests.ResetPasswordRequest;
import com.internshipprojectG1.ride_sharing.service.EmailService;
import com.internshipprojectG1.ride_sharing.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    // ================== REGISTER ==================
    @PostMapping("/register")
    public Users register(@RequestBody Users user) {
        return userService.addUser(user);
    }

    // ================== LOGIN ==================
    @PostMapping("/login")
    public Users login(@RequestBody LoginRequest loginRequest) {
        return userService.loginUser(loginRequest);
    }


    // ================== FORGOT PASSWORD ==================
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody java.util.Map<String, String> request,
                                            HttpServletRequest httpRequest) {

        String email = request.get("email");
        String appUrl = "http://localhost:5173";  // frontend link

        try {
            emailService.createPasswordResetToken(email, appUrl);
        } catch (Exception e) {
            // do not reveal email
        }

        return ResponseEntity.ok().body(
                java.util.Map.of("message", "If an account with that email exists, a reset link has been sent.")
        );
    }

    // ================== RESET PASSWORD ==================
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest request) {

        try {
            emailService.resetPassword(request.getToken(), request.getNewPassword());
            return ResponseEntity.ok(java.util.Map.of("message", "Password reset successful."));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("error", e.getMessage()));
        }
    }

    // ================== VALIDATE TOKEN ==================
    @GetMapping("/validate-reset-token")
    public ResponseEntity<?> validateResetToken(@RequestParam("token") String token) {
        boolean valid = emailService.isTokenValid(token);
        return ResponseEntity.ok(java.util.Map.of("valid", valid));
    }
}
