package com.internshipprojectG1.ride_sharing.repository;

import com.internshipprojectG1.ride_sharing.entity.ForgotPassword;
import com.internshipprojectG1.ride_sharing.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface ForgotPasswordRepository extends JpaRepository<ForgotPassword, Integer> {

    void deleteByEmail(String email);

    @Query("select fp from ForgotPassword fp where fp.otp = ?1 and fp.user = ?2")
    Optional<ForgotPassword> findByOtpAndUsers(Integer otp, Users user);

    Optional<ForgotPassword> findByUser(Users user);
}
